import { BrowserRouter as Router, Routes, Route } from 'react-router-dom'
import Scene1 from './pages/Scene1_Saving'

export default function App() {
  return (
    <Router>
      <Routes>
        <Route path="/" element={<Scene1 />} />
      </Routes>
    </Router>
  )
}
