export default function ChoiceCard({ title, result }) {
  return (
    <div className="bg-card p-6 rounded-xl shadow-xl hover:scale-[1.02] transition-transform cursor-pointer">
      <h2 className="text-xl font-semibold mb-2 text-bitcoin">{title}</h2>
      <p className="text-grayText">{result}</p>
    </div>
  )
}
