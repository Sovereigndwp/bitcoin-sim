import ChoiceCard from '../components/ChoiceCard'

export default function Scene1() {
  return (
    <div className="min-h-screen px-6 py-12">
      <h1 className="text-3xl font-bold text-bitcoin mb-4">Scene 1: Saving for the Future</h1>
      <p className="text-grayText mb-8 max-w-xl">
        It's 2025. You just received your first paycheck. You want to save $1,000 for a trip in 5 years. What do you do?
      </p>

      <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
        <ChoiceCard
          title="High-Yield Fiat Account (5% Interest)"
          result="$1,276 after 5 years. But with inflation, your real purchasing power is closer to $1,072."
        />
        <ChoiceCard
          title="Convert to Bitcoin (0.01 BTC)"
          result="In 5 years, it's worth ~$3,000. You buy the ticket and still have sats left."
        />
      </div>
    </div>
  )
}
