export default {
  content: [
    "./index.html",
    "./src/**/*.{js,ts,jsx,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        bitcoin: "#f7931a",
        base: "#0f0f0f",
        card: "#1a1a1a",
        textLight: "#f4f4f4",
        grayText: "#a3a3a3"
      },
      fontFamily: {
        sans: ['Inter', 'system-ui', 'sans-serif']
      }
    },
  },
  plugins: [],
}
